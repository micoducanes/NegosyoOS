# NegosyoOS MVP (browser prototype)

A responsive, mobile-friendly front-end prototype for small businesses in the Philippines.

## Run it

1. Unzip the project folder.
2. Open `index.html` in a modern browser, or serve it locally with:

   ```bash
   python -m http.server 8000
   ```

3. Visit `http://localhost:8000`.

No build step is required for this prototype.

## Included in this MVP

- Overview dashboard and seven-day sales visualization
- Product inventory with categories, cost, selling price, quantity, and low-stock thresholds
- Sales recording with automatic stock deduction and gross profit calculation
- Cash, GCash, and other payment-method totals for daily remittance summaries
- Expense recording and estimated net operating result
- Monthly reports and CSV exports
- Free and Pro pricing page (Pro checkout is intentionally not live)
- Demo admin utilities, sample data, and business-name setting
- Responsive desktop/mobile layout
- Demo data persistence in browser `localStorage`

## Important limitations

This is a front-end prototype, not a production SaaS. It does **not** provide real user authentication, a remote database, multi-user access controls, server-side admin roles, payment processing, or verified subscription entitlements. `localStorage` is not secure storage and can be edited or deleted by the browser user. Do not store real customer or financial records in this demo.

## Recommended production setup

- Front end: React/Next.js + TypeScript
- Authentication/database: Supabase Auth + PostgreSQL
- Security: enable Row Level Security on every tenant-owned table; derive user identity from the verified session; never trust a client-supplied owner ID. Add tests that prove one business cannot read or modify another business's rows.
- Tables: `businesses`, `business_members`, `products`, `sales`, `sale_items`, `expenses`, `subscriptions`, `payment_events`, `audit_logs`.
- Money: store amounts as integer centavos or PostgreSQL `numeric`, not binary floating-point in the database.
- Payments: integrate a supported Philippine payment provider through server-side checkout creation and signed webhook verification. Unlock Pro only after verifying the provider event on the server, checking amount/currency/status, and handling duplicate webhook delivery idempotently. Never mark a subscription paid from a browser redirect alone. Confirm provider availability, fees, and current integration requirements before launch.
- Admin: protect all admin actions with server-side role checks and audit logs. Never rely on hiding a button in the UI.
- Deployment: deploy the app to a managed host; store secrets only in environment variables; enable HTTPS; configure backups, logging, rate limits, and a privacy policy.

## Suggested plan limits

- Free: up to 20 products, basic dashboard, sales and expenses.
- Pro (suggested test price ₱199/month): higher product limit, reports, exports, and future cloud sync.

Validate pricing with real customers before launch. This prototype's plan selector is a demo only and does not accept payments.
